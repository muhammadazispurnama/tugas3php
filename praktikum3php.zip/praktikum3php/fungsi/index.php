<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
    <div class="containar-fluid">
        <div class="row-mt-5">
            <div class="col-12">
                <form method="post" action="hasil.php">
  <div class="form-group row">
    <label for="text1" class="col-4 col-form-label">Nama lengkap</label> 
    <div class="col-8">
      <input id="nama" name="nama" type="text" class="form-control" required>
    </div>
  </div>
  <div class="form-group row">
    <label for="" class="col-4 col-form-label">Mata kuliah</label> 
    <div class="col-8">
      <select id="matkul" name="matkul" class="custom-select" required>
        <option value="ddp">DDP</option>
        <option value="mtk">MTK</option>
        <option value="pw">PW</option>
      </select>
    </div>
  </div>
  <div class="form-group row">
    <label for="text" class="col-4 col-form-label">UTS</label> 
    <div class="col-8">
      <input id="uts" name="uts" type="number" class="form-control" required>
    </div>
  </div>
  <div class="form-group row">
    <label for="text2" class="col-4 col-form-label">UAS</label> 
    <div class="col-8">
      <input id="uas" name="uas" type="number" class="form-control" required>
    </div>
  </div>
  <div class="form-group row">
    <label for="text3" class="col-4 col-form-label">Nilai tugas</label> 
    <div class="col-8">
      <input id="tugas" name="tugas" type="number" class="form-control" required>
    </div>
  </div> 
  <div class="form-group row">
    <div class="offset-4 col-8">
      <button name="submit" type="submit" class="btn btn-primary">simpan</button>
    </div>
  </div>
</form>
            </div>
        </div>
    </div>
</body>
</html>