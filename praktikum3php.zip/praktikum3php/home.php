<?php
include_once 'atas.php';

?>
<h1>welcome home</h1>
<?php
require_once 'bawah.php';
?>